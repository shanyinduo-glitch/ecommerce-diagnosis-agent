每个 case 目录包含 products.csv、traffic.csv、order_items.csv。
public 模式的 reference answers 可供开发核对。
